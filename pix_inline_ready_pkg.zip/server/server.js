import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import axios from 'axios';
import crypto from 'crypto';
import nodemailer from 'nodemailer';
import PDFDocument from 'pdfkit';
import fs from 'fs';
import path from 'path';
import mercadopago from 'mercadopago';

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));

mercadopago.configure({ access_token: process.env.MP_ACCESS_TOKEN });

const ORDERS = new Map();

function genId(prefix='ord_'){ return prefix + crypto.randomBytes(8).toString('hex'); }

function generateTicketPDF(order, ticketCode){
  const filename = `ticket_${ticketCode}.pdf`;
  const filePath = path.join(process.cwd(), filename);
  const doc = new PDFDocument({ size: 'A6', margin: 20 });
  const stream = fs.createWriteStream(filePath);
  doc.pipe(stream);
  doc.fontSize(16).text('Ingresso • MC Meno K', { align: 'center' });
  doc.moveDown();
  doc.fontSize(12).text(`Nome: ${order.buyer?.nome} ${order.buyer?.sobrenome}`);
  doc.text(`E-mail: ${order.buyer?.email}`);
  doc.text(`Celular: ${order.buyer?.celular}`);
  doc.moveDown();
  const totalQty = order.items.reduce((a,b)=>a+b.quantity,0);
  const totalVal = order.items.reduce((a,b)=>a+b.quantity*b.unit_price,0);
  doc.text(`Itens: ${totalQty}`);
  doc.text(`Valor: R$ ${totalVal.toFixed(2)}`);
  doc.moveDown();
  doc.fontSize(12).text('Evento: 07/11/2025 — 23:00');
  doc.text('Local: Av. Pres. Getúlio Vargas, 614 — Alvorada/RS');
  doc.moveDown();
  doc.fontSize(14).text(`Código: ${ticketCode}`, { align:'center' });
  doc.end();
  return new Promise((resolve) => { stream.on('finish', ()=> resolve(filePath)); });
}

async function sendTicketEmail(order, ticketPath){
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT || '587', 10),
    secure: false,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
  const total = order.items.reduce((a,b)=>a+b.quantity*b.unit_price,0);
  await transporter.sendMail({
    from: process.env.MAIL_FROM || '"Pilares Club" <no-reply@pilares.club>',
    to: order.buyer.email,
    subject: 'Seu ingresso - MC Meno K',
    text: `Olá ${order.buyer.nome},\n\nPagamento confirmado! Em anexo está seu ingresso (PDF).\n\nValor: R$ ${total.toFixed(2)}\nNos vemos no evento!`,
    html: `<p>Olá <b>${order.buyer.nome}</b>,</p>
           <p>Pagamento confirmado! Em anexo está seu ingresso (PDF).</p>
           <p><b>Valor:</b> R$ ${total.toFixed(2)}</p>
           <p>Nos vemos no evento!</p>`,
    attachments: [{ filename: path.basename(ticketPath), path: ticketPath }]
  });
}

async function sendPurchaseToMetaCAPI(order){
  try{
    const pixelId = process.env.FB_PIXEL_ID;
    const accessToken = process.env.FB_ACCESS_TOKEN;
    if(!pixelId || !accessToken) return;
    const event_time = Math.floor(Date.now()/1000);
    const total = order.items.reduce((a,b)=>a+b.quantity*b.unit_price,0);
    const email = (order.buyer.email || '').trim().toLowerCase();
    const phoneDigits = (order.buyer.celular || '').replace(/\D+/g,'');
    const fn = (order.buyer.nome || '').trim().toLowerCase();
    const ln = (order.buyer.sobrenome || '').trim().toLowerCase();
    const sha256 = (val) => crypto.createHash('sha256').update(val).digest('hex');
    const payload = {
      data: [{
        event_name: 'Purchase',
        event_time,
        action_source: 'website',
        event_source_url: process.env.SITE_URL || 'https://example.com',
        user_data: {
          em: email ? sha256(email) : undefined,
          ph: phoneDigits ? sha256(phoneDigits) : undefined,
          fn: fn ? sha256(fn) : undefined,
          ln: ln ? sha256(ln) : undefined
        },
        custom_data: {
          currency: 'BRL',
          value: total,
          content_ids: ['mc-meno-k-2025'],
          num_items: order.items.reduce((a,b)=>a+b.quantity,0)
        }
      }]
    };
    const url = `https://graph.facebook.com/v17.0/${pixelId}/events?access_token=${accessToken}`;
    await axios.post(url, payload);
  }catch(e){
    console.error('Erro CAPI:', e.response?.data || e.message);
  }
}

app.post('/api/create_preference', async (req, res) => {
  try{
    const { buyer, items } = req.body;
    if(!buyer || !items || !Array.isArray(items) || items.length===0){
      return res.status(400).json({ error: 'Pedido inválido' });
    }
    const orderId = genId();
    const preference = {
      items: items.map(i => ({
        id: i.id, title: i.title, quantity: i.quantity, unit_price: Number(i.unit_price), currency_id: 'BRL'
      })),
      payer: { name: `${buyer.nome} ${buyer.sobrenome}`, email: buyer.email },
      external_reference: orderId,
      back_urls: {
        success: (process.env.SITE_URL || 'https://example.com') + '/sucesso',
        failure: (process.env.SITE_URL || 'https://example.com') + '/falhou',
        pending: (process.env.SITE_URL || 'https://example.com') + '/pendente'
      },
      auto_return: 'approved'
    };
    const pref = await mercadopago.preferences.create(preference);
    ORDERS.set(orderId, { status:'pending', buyer, items, mpPreferenceId: pref.body.id });
    res.json({ id: pref.body.id, orderId });
  }catch(e){
    console.error(e);
    res.status(500).json({ error: 'Erro ao criar preferência' });
  }
});

app.get('/api/order_status', (req, res) => {
  const { orderId } = req.query;
  const o = ORDERS.get(orderId);
  if(!o) return res.status(404).json({ error: 'Pedido não encontrado' });
  res.json({ status: o.status });
});

app.post('/api/mp_webhook', async (req, res) => {
  try{
    const topic = req.query.topic || req.query.type;
    const id = req.query['data.id'] || req.query.id;
    if(topic !== 'payment' || !id){
      return res.status(200).send('ok');
    }
    const pay = await mercadopago.payment.findById(id);
    const status = pay.body.status;
    const external_reference = pay.body.external_reference;
    if(status === 'approved' && external_reference){
      const order = ORDERS.get(external_reference);
      if(order && order.status !== 'paid'){
        order.status = 'paid';
        order.mpPaymentId = id;
        const code = genId('TK_').toUpperCase();
        const pdfPath = await generateTicketPDF(order, code);
        await sendTicketEmail(order, pdfPath);
        await sendPurchaseToMetaCAPI(order);
        try{ fs.unlinkSync(pdfPath); }catch(e){}
      }
    }
    res.status(200).send('ok');
  }catch(e){
    console.error('Webhook error:', e.response?.data || e.message);
    res.status(200).send('ok');
  }
});

import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
app.use(express.static(path.join(__dirname, '..', 'site')));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log('Server running on port', port));
